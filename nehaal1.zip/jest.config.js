module.exports = {
  testEnvironment: 'node'
};
