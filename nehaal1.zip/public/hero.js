// Background waves are now handled purely with CSS strips.
